﻿using MDO.Desktop.Models;
using MDO.Desktop.Services.Commands;


namespace MDO.Desktop.Services.Factories
{
    public class DatabaseCommandFactory
    {

        private readonly IHttpClientWrapper _client;

        public DatabaseCommandFactory(IHttpClientWrapper client)
        {
            _client = client;
        }

        public IDatabaseCommand<ApiResponse<string>> ConnectCommand(DatabaseConnectionDto dto)
        {
            return new ConnectCommand(_client, dto);
        }

        public IDatabaseCommand<ApiResponse<string>> GetVersionCommand()
        {
            return new GetVersionCommand(_client);
        }

        public IDatabaseCommand<ApiResponse<string>> DisconnectCommand()
        {
            return new DisconnectCommand(_client);
        }
        
    }
}
